var express = require('express');
var router = express.Router();
const path = require('path');
const fs = require('fs');
const https = require('https');
const querystring = require('querystring');

// If you are working with other servers, please change this const.
const defaultServer = 'dev.deltaware.ca';

router.all('/*', async function (req, res, next) {
  let urlPath = req.path;
  let reqMethod = req.method.toLowerCase();
  let reqQuery = req.query;
  let expectRes = req.query.expectRes;
  delete req.query.expectRes;
  let parameter = JSON.stringify(req.body, null, 2);
  let reqHeaders = req.headers;
  console.log(`Request body is ${parameter}`);
  let responseJson = '';
  // JSON file path
  let jsonFilePath = await getJsonFilePath(urlPath, expectRes, reqMethod, reqQuery);

  console.log(`looking for the file: ${jsonFilePath}`);
  if (fs.existsSync(jsonFilePath)){
    // return the json file as the response
    console.log(`File found. ${jsonFilePath}`);
    responseJson = await fs.readFileSync(jsonFilePath);
    let httpCode = getHttpCode(expectRes) || 200;
    res.status(httpCode);
    res.setHeader('Content-Type', 'application/json');
    console.log(`Response is: ${responseJson}`);
    res.send(responseJson);
  } else {
    // working as a proxy.
    console.log(`File not found. working as a proxy. Default server is ${defaultServer}`);
    let headers = {
      'Authorization': reqHeaders.Authorization || reqHeaders.authorization || ''
    }
    
    const httpsOptions = {
      hostname: defaultServer,
      port: 443,
      path: urlPath,
      method: reqMethod.toUpperCase(),
      headers: headers
    };

    const reqData = JSON.stringify(req.body);
    if(httpsOptions.method !== 'GET'){
      headers['Content-Type'] = reqHeaders['Content-Type'] || reqHeaders['content-type'] || 'application/json';
      headers['Content-Length'] = reqData.length;
    }
    
    if(reqQuery && Object.keys(reqQuery).length>0){
      const newSearchParams = new URLSearchParams(reqQuery);
      httpsOptions.path = `${httpsOptions.path}?${newSearchParams.toString()}`;
    }

    const proxyReq = https.request(httpsOptions, proxyRes =>{
      console.log(`${defaultServer} returns statusCode: ${proxyRes.statusCode}`);
      proxyRes.on('data', data => {
        res.status(proxyRes.statusCode);
        res.set(proxyRes.headers);
        let postFilePath = path.join(__dirname, '..', 'mock', urlPath, 'post.js');
        if(fs.existsSync(postFilePath)){
          res.send(runPostResonse(postFilePath, JSON.parse(data.toString('utf8'))))
        }else{
          res.send(data);
        }
      })
    });

    proxyReq.on('error', error=>{
      console.log(error);
    });

    if(httpsOptions !== 'GET'){
      proxyReq.write(reqData);
    }
    proxyReq.end();
  }

});

// Get the JSON file path based on the request parameter and rule.txt
async function getJsonFilePath(urlPath, expectRes, reqMethod, reqQuery){
  let parentPath = path.join(__dirname, '..', 'mock', urlPath);

  // Search rule file path, the url like /{claimID}/{userId}
  let queryResultRule = path.join(__dirname, '..', 'mock', urlPath, 'rule.txt');
  if (fs.existsSync(queryResultRule)) {
    let rule = fs.readFileSync(queryResultRule).toString('utf8');
    // Get the additionalPath based on rule.txt
    let additionalPath = replacePathWithQuery(rule, reqQuery);
    if(additionalPath){
      parentPath = path.join(parentPath, additionalPath);
    }
  }
  let fileName = expectRes ? reqMethod + '_' + expectRes + '.json' : reqMethod + '.json';
  return path.join(parentPath, fileName);
}

// Get the real path based on the query parameter.
function replacePathWithQuery(rule, reqQuery){
  if(reqQuery){
    Object.keys(reqQuery).forEach(e => {
      rule = rule.replace('${'+e+'}', reqQuery[e]);
    });
    return rule;
  } else {
    return rule;
  }
}

// Get the http code from the request parameter(expectRes)
function getHttpCode(expectRes){
  let httpCode = 200;
  if (expectRes && expectRes.indexOf('_') > 0) {
    httpCode = expectRes.substring(0, expectRes.indexOf('_'));
  }
  if (httpCode != '200') {
    httpCode = parseInt(httpCode);
  } else {
    httpCode = parseInt(expectRes);
  }
  if (Number.isInteger(httpCode) && httpCode < 600) {
    return httpCode;
  }else{
    return undefined;
  }
}

// Run post.js and return the result
function runPostResonse(postFilePath, data){
  let rs = require(postFilePath);
  return rs.default(data);
}

module.exports = router;
