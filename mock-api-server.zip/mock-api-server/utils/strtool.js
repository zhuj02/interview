const types = {
  //refills: "# of refills",
  adjstdAmnt: "Adjusted Amount",
  approvedAmount: "Approved Amoun",
  aprvdFeeCde: "Approved Fee Code",
  aprvdFeeId: "Approved Fee ID",
  atcCode: "ATC Code",
  autoSubmissionFlag: "Auto Submission Flag",
  beneficiaryId: "Beneficiary ID",
  bypsFlg: "Bypass Flag",
  cardholderPartialName: "Cardholder Partial Name",
  carrierId: "Carrier ID",
  cmnSrceId: "Claim Source ID",
  //status: "Claim Status",
  clmType: "Claim Type",
  clientIdentifier: "Client Identifier",
  clientIdentifierTypeId: "Client Identifier Type",
  clncSteId: "Clinic Site ID",
  comment: "Comment",
  compoundInvoiceInd: "Compound Invoice Ind",
  compoundType: "Compound Type",
  compoundingTimeUnit: "Compounding Time Unit",
  compoundingTimeValue: "Compounding Time Value",
  cphaVersionNumber: "cpha Version Number",
  createdBy: "Created By",
  createdByP: "Created By Pharmacy",
  createdOn: "Created On",
  createdOnP: "Created On Pharmacy",
  currentRxNum: "Current Rx Number",
  currentUnitPrice: "Current Unit Price",
  dateOfBirth: "Date of Birth",
  dateOfPayment: "Date of Payment",
  dateProcessed: "Date Processed",
  daysSupply: "Days Supply",
  deductibleToCollect: "Deductible to Collect",
  diagnosis: "Diagnosis",
  diagnosisType: "Diagnosis Type",
  dinCategoryId: "DIN Category ID",
  disPrescriptionId: "DIS Prescription Id",
  diagnosisId: "Disganosis Id",
  dispensePackageSize: "Dispense Package Size",
  dspnsdDosageForm: "Dispensed Dosage Form",
  dspnsdQuantityUnit: "Dispensed Dosage Unit",
  sig: "Dispensed Sig",
  dspnsdSubprogramCodeId: "Dispensed Subprogram Code ID",
  durDeleteDate: "DUR Delete Date",
  fcltyTypeId: "Facility Type ID ",
  feeCtgryId: "Fee Category Id",
  feeId: "Fee ID",
  //serviceDate: "Fill Date",
  firstName: "First Name",
  gcnSequenceNumber: "GCN Sequence Number",
  gender: "Gender",
  grossAmnt: "Gross Amount",
  groupOfMemberId: "Group of Member Id",
  hstryOnlyFlg: "History Only Flag",
  hldUntlDte: "Hold Until Date",
  id: "Id",
  idP: "Id Pharmacy",
  interventionCodes: "Intervention Codes",
  invoiceNumber: "Invoice Number",
  issuesInd: "Issues Identified",
  lastRefillDate: "Last Refill Date",
  lstRmtDte: "Last Remit Date",
  localSystemIdExt: "Local System Id External",
  localSystemIdRoot: "Local System Id Root",
  maximumAllowableCost: "Maximum Allowable Cost",
  medicalCondition: "Medical Condition",
  medicalReasonRefCode: "Medical Reason Ref Code",
  //fillType: "New/Refill Code",
  orgnlRmtDte: "Original Remit Date",
  originalRxNum: "Original Rx Number",
  orgnlSbmtDte: "Original Submit Date",
  overrideType: "Override Type",
  //priorAuthorizationId: "PA ID",
  paidAmount: "Paid Amount",
  paidCoinsurance: "Paid Coinsurance",
  paidCoinsurance_1: "Paid Coinsurance_1",
  paidCompoundFee: "Paid Compund Fee",
  paidCopaymentToCollect: "Paid Copayment to Collect",
  paidCostUpcharge: "Paid Cost Upcharge",
  paidDaysSupply: "Paid Days Supply",
  paidDrugCost: "Paid Drug Cost",
  paidGenericIncentive: "Paid Generic Incentive",
  paidProfessionalFee: "Paid Professional Fee",
  paidQuantity: "Paid Quanity",
  paidSpecialServicesFee: "Paid Special Services Fee",
  paidSubprogramCode: "Paid Subprogram Code",
  paidSubprogramCodeId: "Paid Subprogram Code Id",
  paidUnitPrice: "Paid Unit price",
  payeeId: "Payee Id",
  payeeType: "Payee Type",
  pharmacistId: "Pharmacist Id",
  pharmacyId: "Pharmacy Id",
  phn: "PHN",
  prescriberBillingNumber: "Prescriber Billing Number",
  prescriberId: "Prescriber Id",
  prescriberReferenceId: "Prescriber Reference Id",
  prescriberType: "Prescriber Type",
  prvsClmStts: "Previous Claim Status",
  //product: "Product Description",
  //productDosage: "Product Dosage",
  //productId: "Product Id",
  productName: "Product Name",
  productRoute: "Product Route",
  productSelectionReason: "Product Selection Reason",
  //productStrength: "Product Strength",
  //program: "Program",
  prgrmId: "Program Id",
  prvdrId: "Provider Id",
  providerSoftwareId: "Provider Software Id",
  providerSoftwareVersion: "Provider Software Version",
  provincialSchedule: "Prvincial Schedule",
  quantity: "Quantity",
  receivedDate: "Received Date",
  relationshipCode: "Relationship Code",
  rleStts: "Rule Status",
  srceId: "Source Id",
  specialServiceCodes: "Special Services Codes",
  submissionDate: "Submission Date",
  submissionType: "Submission Type",
  submittedAmount: "Submitted Amount",
  submittedCompoundFee: "Submitted Compound Fee",
  submittedCostUpcharge: "Submitted Cost Upcharge",
  submittedPreviouslyPaid: "Submitted Previously Paid",
  submittedProductCost: "Submitted Product Cost",
  submittedProfessionalFee: "Submitted Professional Fee",
  submittedSpecialServicesFee: "Submitted Special Services Fee",
  substitutionCode: "Substitution Code",
  substitutionReasonCode: "Substitution Reason Amount",
  surname: "Surname ",
  tax1: "Tax1",
  tax2: "Tax2",
  tax3: "Tax3",
  traceNumber: "Trace Number",
  trnsmsnId: "Transmission Id",
  unitPriceAmt: "Unit Price Amount",
  unitPriceUnit: "Unit Price Amount",
  updatedBy: "Updated By",
  updatedByP: "Updated By Pharmacy",
  updatedOn: "Updated On",
  updatedOnP: "Updated On Pharmacy",
  //claimVersion: "Version",
  vrsnP: "Version Pharmacy",
};


const text = `
CLM_STTS
DSPNSD_DRUG_DESCRIPTION
DTE_OF_SRVCE
CLMD_AMNT
APRVD_AMNT
FEE_CDE
DSPNSD_DRUG_COST
PRGRM_ID
SRCE_ID
TRNSMSN_ID
CLM_TYPE
PRVDR_ID
FEE_ID
FEE_CTGRY_ID
APRVD_FEE_ID
PAID_UNIT_PRICE
APRVD_FEE_CDE
FCLTY_TYPE_ID
ORGNL_SBMT_DTE
ORGNL_RMT_DTE
LST_SBMT_DTE
LST_RMT_DTE
CREATED_ON
CREATED_BY
UPDATED_ON
UPDATED_BY
PRVS_CLM_STTS
PYMNT_DTE
PAID_AMNT
ADJSTD_AMNT
GROSS_AMNT
DSPNSD_SUBPROGRAM_CODE
DSPNSD_SUBPROGRAM_CODE_ID
DATE_PROCESSED
DATE_PAPER_CLAIM_RECEIVED
SUBMISSION_METHOD
CLIENT_DATE_OF_BIRTH
CARDHOLDER_PARTIAL_NAME
RELATIONSHIP_CODE
CLIENT_FIRST_NAME
CLIENT_LAST_NAME
PHN
CLIENT_GENDER_CODE
GROUP_OF_MEMBER_ID
MEDICAL_REASON_REF_CODE
MEDICAL_CONDITION
NEW_REFILL_CODE
NUMBER_REFILLS
ORIGINAL_PRESCRIPTION_NUMBER
CURRENT_PRESCRIPTION_NUMBER
SPECIAL_SERVICE_CODE
DSPNSD_QUANTITY
DSPNSD_DAYS_SUPPLY
DSPNSD_SELECTION_CODE
COMPOUND_CODE
SPECIAL_AUTHORIZATION_NUMBER
DSPNSD_INTERVENTION_CODE
AUTHORIZATION_CODE
DSPNSD_SIG
PRESCRIBER_ID_REFERENCE
PRESCRIBER_ID
PRESCRIBER_TYPE
PHARMACIST_ID
DUR_DELETE_DATE
DSPNSD_STRENGTH
DSPNSD_DOSAGE
DSPNSD_DOSAGE_FORM
PROVINCIAL_SCHEDULE
PAID_SUBPROGRAM_CODE
PAID_SUBPROGRAM_CODE_ID
DIN_CATEGORY_ID
DSPNSD_COST_UPCHARGE
DSPNSD_PROFESSIONAL_FEE
DSPNSD_COMPOUND_FEE
DSPNSD_SPECIAL_SERVICES_FEE
DSPNSD_PREVIOUSLY_PAID
MAXIMUM_ALLOWABLE_COST
PAID_COINSURANCE
PAID_DRUG_COST
PAID_COST_UPCHARGE
PAID_GENERIC_INCENTIVE
PAID_PROFESSIONAL_FEE
PAID_COMPOUND_FEE
PAID_SPECIAL_SERVICES_FEE
COPAYMENT_TO_COLLECT
DEDUCTIBLE_TO_COLLECT
COINSURANCE_TO_COLLECT
CURRENT_UNIT_PRICE
PAID_QUANTITY
PAID_DAYS_SUPPLY
TAX1
TAX2
TAX3
PAYEE_TYPE
PAYEE_ID
CREATED_ON_P
CREATED_BY_P
UPDATED_ON_P
UPDATED_BY_P
INVOICE
TRACE_NUMBER
PRESCRIBER_BILLING_NUMBER
ID
VRSN
ID_P
VRSN_P
LOCAL_SYSTEM_ID_EXT
CPHA_VERSION_NUMBER
PROVIDER_SOFTWARE_CODE
PROVIDER_SOFTWARE_VERSION
CARRIER_ID
GCN_SEQUENCE_NUMBER
ATC_CODE
DSPNSD_ROUTE_ADMIN
AUTO_SUBMISSION_FLAG
LOCAL_SYSTEM_ID_ROOT
DIS_PRESCRIPTION_ID
SUBSTITUTION_CODE
SUBSTITUTION_REASON_CODE
DISPENSE_PACKAGE_SIZE
UNIT_PRICE_AMT
UNIT_PRICE_UNIT
COMPOUND_INVOICE_IND
COMPOUNDING_TIME_VALUE
COMPOUNDING_TIME_UNIT
LAST_REFILL_DATE
ISSUES_IND
DSPNSD_QUANTITY_UNIT
CLIENT_IDENTIFIER
CLIENT_IDENTIFIER_TYPE_ID
RLE_STTS
CLNC_STE_ID
CLNT_ID
FCLTY_ID
CMNT
BYPS_FLG
HSTRY_ONLY_FLG
HLD_UNTL_DTE
CMN_SRCE_ID



`;

function readAndSort(obj){
    const keysArray = Object.keys(obj);
  const pairArray = [];
  for (let i = 0; i < keysArray.length; i++) {
    const tmpPair = {
        key: keysArray[i],
        value: obj[keysArray[i]]
    }
    pairArray.push(tmpPair);
  }
  pairArray.sort((a,b) => {
    return a.value.localeCompare(b.value);
  })
  return pairArray;
}

function outputFilters(obj) {
  const pairArray = readAndSort(obj);
  
  for (let i = 0; i < pairArray.length; i++) {
    console.log("{");
    console.log(`    "label": "${pairArray[i].value}",`);
    console.log(`    "property": "${pairArray[i].key}"`);
    console.log("},");
  }
}

function outputFields(obj) {
    const pairArray = readAndSort(obj);
  for (let i = 0; i < pairArray.length; i++) {
    console.log("{");
    console.log(`    "title": "${pairArray[i].value}",`);
    console.log(`    "paths": ["${pairArray[i].key}"],`);
    console.log(`    "hidden": true`);
    console.log("},");
  }
}

function snakeToCamel(str, firstLetterInUpperCase) {
  const words = str.toLowerCase().split(/[_-]/);
  for (let i = 0; i < words.length; i++) {
    if(words[i][0]){
        words[i] = words[i][0].toUpperCase() + words[i].slice(1);
    }
  }
  if(!firstLetterInUpperCase){
    words[0] = words[0].toLowerCase();
  }
  console.log(words.join(''));
  return words.join('');
}

function convertToCamelcase(txt){
    const lines = txt.split('\n');
    for (let i = 0; i < lines.length; i++) {
        snakeToCamel(lines[i].trim());
    }
}

function test1(template){
    const reqs = template?.terms?.REQUIREMENTS.split(/ *, */);
    for (let parameterNameAndType of reqs) {
      if(!parameterNameAndType || !parameterNameAndType[0]){
        continue;
      }
      const parameterName = parameterNameAndType.trim().split(/ *: */)[0];
      console.log(parameterName+'---sdfsdf');
    }
}
console.log("-------------------------------------------------------");
//outputFilters(types);
//outputFields(types);
//snakeToCamel('DSPNSD_DRUG_DESCRIPTION')
//convertToCamelcase(text);
test1({
    terms:{
        REQUIREMENTS: 'Priorauthorization,,,,Sysdate: 	Date,	Sysdd:String,PPPDF,'
    }
})
console.log("-------------------------------------------------------");



