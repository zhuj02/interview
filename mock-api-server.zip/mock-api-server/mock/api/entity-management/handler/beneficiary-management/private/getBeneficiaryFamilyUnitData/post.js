module.exports.default = function(data){
    console.log(data);
    data[0].roleDescription = "Primary";
    const objStr = JSON.stringify(data[0]);
    
    data[1] = JSON.parse(objStr);
    data[1].target.id = 12345;
    data[1].endedOn = "2015-09-12";
    data[1].roleDescription = "Spouse";

    data[2] = JSON.parse(objStr);
    data[2].target.id = 23456;
    data[2].roleDescription = "Dependent";
    data[2].endedOn = "2015-01-12";

    for(let i=3; i<20; i++){
        data[i] = JSON.parse(objStr);
        data[i].target.id = data[i].target.id + i;
        data[i].endedOn = "2015-09-12";
    }
    return data;
};