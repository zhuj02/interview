module.exports.default = function(data){
    // console.log(data);
    data.newproperty = "123456";
    data.claimedAmount = "$4.6666123456";
    return data;
};