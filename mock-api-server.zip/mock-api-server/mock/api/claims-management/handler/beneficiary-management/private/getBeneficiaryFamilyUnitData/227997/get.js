[{
    "entityType": "FamilyUnitMembership",
    "memberId": 195404,
    "roleType": "FUP",
    "startedOn": "2020-08-12",
    "target": {
        "entityType": "FamilyUnit",
        "id": 20902
    },
    "owner": {
        "id": 227997
    }
}]