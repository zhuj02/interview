module.exports.default = function(data){
    console.log(data);
    data.claimDetails.aaaaa = "aaaaaaaaaaa";
    data.claimDetails.bbb = "aaaaaaaaaaa";
    data.claimDetails.cccc = "aaaaaaaaaaa";
    return data;
};