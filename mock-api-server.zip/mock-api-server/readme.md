# Mock service

This project is for mocking the data form the server side. Basically, it just returns the json file stored in the mock directory, but if the file doesn't exist, it works as a proxy to retrive the data from the default server.

## Working flow

```mermaid
flowchart TB
    A[Get the request] --> B{Has expectRes?}
    B --> |Yes| C[Get the Json file name with request type and exceptRes]
    B --> |No| D[Get the Json file name with request type]
    C --> E{Has rule.txt?}
    D --> E
    E --> |Yes| F[Get the path with url and rule.txt]
    E --> |No| G[Get the path with url]
    F --> I{File exist?}
    G --> I
    I --> |Yes| J[Read the JSON file]
    I --> |No| K[Work as a proxy to the default server]
    J --> L{expectRes has http code?}
    L --> |Yes|M[Return the JSON file \n content with http code 200]
    L --> |No|N[Return the JSON file content with \n the http code defined in expectRes]
    M --> Z[END]
    N --> Z[END]
    K --> O{Has post.js}
    O --> |Yes| P[Call post.js and return \n the result of default function]
    O --> |No| Q[Return the result from the server]
    P --> Z[END]
    Q --> Z[END]

```

## How to run this project

1. Clone the project to the local
2. Run "npm install"
3. Run the server with the command "node ./bin/www", the default port is 3000.
4. Make changes in "mock" directory.
5. Change the nginx configuration to make it can intercept the https request.
6. Send a request to localhost to see if it works.

## How to add new request json

The json file store directory is based on the url. The json file name based on the http request type and url parameter "expectRes".

Ex: The request is "/api/v3/address/provinceType/CAN/"
    The directory is "/mock/api/v3/address/provinceType/CAN/"

This directory can have lots json file.

Ex:

``` 

get.json           // http get request
post.json          // http post request
delete.json        // http delete request
patch.json         // http patch request
put.json           // http put request
get_401.json       // http get request, return http 401 code, the url has parameter "?expectRes=401"
post_id_conflict.json   // http post request, return http 200 code with id confilct error message
post_403_fail.json      // http post request, return http 403 code with fail error message

```

## How to return the search result

The search result is different. We need a rule file to define the path of the result. The content of the rule file is define the path. The parameter in the path use the format "${NAME_OF_VAR}", ex: /${claimId}/

Ex:

URL: "/api/claims-management/handler/claims-management/private/viewClaim?claimId=19005250"

Request Type: GET

Rule File: "/mock/api/claims-management/handler/claims-management/private/viewClaim/rule.txt"

Rule file content: /${claimId}/

The json file path: "/mock/api/claims-management/handler/claims-management/private/viewClaim/19005250/get.json"

## How to modify the returns from the default server

User can change the returns from the default server with post.js. With post.js, user can add some new properties, or modify the values.

Ex:

URL: "/api/claims-management/handler/claims-management/private/viewClaim?claimId=19005251"

Post file: "/mock/api/claims-management/handler/claims-management/private/viewClaim/post.js"

```js
module.exports.default = function(data){
    console.log(data);
    data.claimDetails.newProperty = "I am a new property.";
    return data;
};
```

Call the default function of the post.js. The parameter of the default function is the return data from the default server. The return of the default will be sent to the user.

If you use post.js, please use nodemon to start the server. Otherwise, the server needs a restart to make the change of js file work.

``` sh
# Install the nodemon command globally. 
npm install -g nodemon
# Run the server with nodemon.
nodemon ./bin/www
```
