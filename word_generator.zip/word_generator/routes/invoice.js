var express = require("express");
var router = express.Router();

/* GET home page. */
router.get("/", function (req, res, next) {
  const rsData = {
    createdDateTime: "2023-01-03 09:33:23",
    invoiceNumber: "23423423423",
    customerId: "C334-098-9454",
    firstName: 'John',
    lastName: 'Bush',
    address:{
      line1: "123 Main Street",
      line2: "Apt. 204",
      city: "Charlottetown",
      province: "PE",
      postalCode: "Q1Q1Q1"
    },
    items:[
      {
        quantity: 10,
        description: "20” x 30” hanging frames ",
        unitPrice: 15.00,
        lineTotal: 150.00
      },
      {
        quantity: 50,
        description: "5” x 7” standing frames",
        unitPrice: 5.00,
        lineTotal: 250.00
      },
    ],
    subTotal: 400.00,
    salesTax: 20.00,
    total: 420.00
  };
  res.send(JSON.stringify(rsData, null, 4));
});

module.exports = router;
