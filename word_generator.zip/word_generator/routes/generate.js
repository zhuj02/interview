var express = require('express');
var router = express.Router();
var generateDocService = require('../services/generateService')

/* GET users listing. */
router.post('/', async function(req, res, next) {
  const data = req.body.data;
  const destination = req.body.destination;
  const templatePath = req.body.templatePath;
  const generateResult = await generateDocService(data, templatePath, destination);
  res.json(generateResult);
});

module.exports = router;
