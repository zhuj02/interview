const PizZip = require("pizzip");
const Docxtemplater = require("docxtemplater");
const expressionParser = require("docxtemplater/expressions.js");
const fs = require("fs");
const path = require("path");
const { sortBy } = require("lodash");

expressionParser.filters.keep2digits = function (input) {
  // Make sure that if your input is undefined, your
  // output will be undefined as well and will not
  // throw an error
  if (!input) return input;
  return Number(input).toFixed(2);
};

expressionParser.filters.money = function (input) {
  // Make sure that if your input is undefined, your
  // output will be undefined as well and will not
  // throw an error
  if (!input) return input;
  return `$${Number(input).toFixed(2)}`;
};

expressionParser.filters.sortBy = function (input, ...fields) {
  // In our example fields is ["price"]

  // Make sure that if your input is undefined, your
  // output will be undefined as well and will not
  // throw an error
  if (!input) return input;
  return sortBy(input, fields);
};

async function generateDocx(data, templatePath, outputFileName) {
  // Load the docx file as binary content
  const content = fs.readFileSync(path.resolve(__dirname, "..", "templates", templatePath), "binary");

  const zip = new PizZip(content);

  const doc = new Docxtemplater(zip, {
    paragraphLoop: true,
    linebreaks: true,
    parser: expressionParser,
    nullGetter() {
      return "";
    },
  });

  // Render the document (Replace {first_name} by John, {last_name} by Doe, ...)
  doc.render(data);

  const buf = doc.getZip().generate({
    type: "nodebuffer",
    // compression: DEFLATE adds a compression step.
    // For a 50MB output document, expect 500ms additional CPU time
    compression: "DEFLATE",
  });

  // buf is a nodejs Buffer, you can either write it to a
  // file or res.send it with express for example.
  fs.writeFileSync(path.resolve(__dirname, "..", "output", outputFileName), buf);
  return {
    success: true,
    filePath: outputFileName
  }
}

module.exports = generateDocx;
