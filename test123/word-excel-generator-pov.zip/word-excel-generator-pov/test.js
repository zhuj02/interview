const fs = require('fs');
const mammoth = require('mammoth');
const PDFDocument = require('pdfkit');

function convertToPDF(inputPath, outputPath) {
  fs.readFile(inputPath, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading Word document:', err);
      return;
    }

    mammoth.extractRawText({ path: 'aa.docx' })
      .then(result => {
        const pdfDoc = new PDFDocument();
        pdfDoc.pipe(fs.createWriteStream(outputPath));
        pdfDoc.text(result.value);
        pdfDoc.end();
        console.log('PDF conversion completed successfully.');
      })
      .catch(error => {
        console.error('Error converting to PDF:', error);
      });
  });
}

convertToPDF('./aa.docx', 'output.pdf');
