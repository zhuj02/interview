const fs = require("fs");
const path = require("path");
const oracledb = require("oracledb");
const xmlService = require("../services/xmlService");
const axios = require("axios");
const _ = require("lodash");

async function loadData(reportConfig, param, xmlData, requestHeader) {
  const datasources =  xmlService.getDatasourceConfigs(reportConfig);
  const endpoints = getAllEndpoints(reportConfig);
  const queries = await xmlService.parseQueryFromXml(xmlData);
  let ret = {};
  if (endpoints.length > 0) {
    for (let i = 0; i < endpoints.length; i++) {
      const endpoint = endpoints[i];
      const ds = xmlService.findDatasource(datasources, "url", endpoint.$.dataSource);
      const tmpData = await getEndpointResponse(endpoint, param, ds, requestHeader);
      if (tmpData) {
        _.merge(ret, tmpData);
      }
    }
  }
  if (queries.length > 0) {
    let connection;
    let dataSourceId;
    try {
      // Loop all the queries
      for (let i = 0; i < queries.length; i++) {
        let query = queries[i];
        const queryObj = await xmlService.parseQueryTag(query, param);
        const ds = xmlService.findDatasource(datasources, "sql", queryObj.dataSource);
        // Keep using the previous connection, until the datasource id is changed.
        if (!connection) {
          connection = await getDBConnection(ds.dbUrl, ds.dbUser, ds.dbPassword);
          dataSourceId = ds.id;
        } else if (ds.id && ds.id !== dataSourceId) {
          await connection.close();
          connection = await getDBConnection(ds.dbUrl, ds.dbUser, ds.dbPassword);
          dataSourceId = ds.id;
        }
        const queryResult = await getQueryResult(queryObj, param, connection);
        if (queryResult) {
          _.merge(ret, queryResult);
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      if (connection) {
        try {
          await connection.close();
        } catch (err) {
          console.error(err);
        }
      }
    }
  }
  return ret;
}

async function getDataFromUrl(reportConfig, param) {
  const dataSourceConfig = await xmlService.getDBConnectionInfo(reportConfig);
  // The endpoints is an array if the config has multiple endpoint tags,
  // Otherwise it is just an object.
  const endpoints = reportConfig.template.endpoint;
  let rs = {};
  if (Array.isArray(endpoints)) {
    for (let i = 0; i < endpoints.length; i++) {
      if (dataSourceConfig.authType === "oauth2" && !dataSourceConfig.authToken) {
        dataSourceConfig.authToken = await getToken(dataSourceConfig);
      }
      const queryResult = await getEndpointResponse(endpoints[i], param, dataSourceConfig);
      if (queryResult) {
        _.merge(rs, queryResult);
      }
    }
  } else {
    rs = getEndpointResponse(endpoints, dataSourceConfig);
  }
  return rs;
}

function getAllEndpoints(reportConfig) {
  const endpoints = reportConfig.template.endpoint;
  let rs = [];
  if (Array.isArray(endpoints)) {
    for (let i = 0; i < endpoints.length; i++) {
      rs.push(endpoints[i]);
    }
  } else if (endpoints) {
    rs.push(endpoints);
  }
  return rs;
}

/**
 * Get the data from Database
 * @param {*} reportConfig The pased xml config
 * @param {*} param The parameter received from url call.
 * @param {*} xmlData The raw xml content(before parsed).
 * @returns
 */
async function getDataFromDB(reportConfig, param, xmlData) {
  const webConnectionInfo = reportConfig.template.dataSource.property;
  let dbUrl = xmlService.getProperyValueByName(webConnectionInfo, "url");
  let dbUser = xmlService.getProperyValueByName(webConnectionInfo, "username");
  let dbPassword = xmlService.getProperyValueByName(webConnectionInfo, "password");
  let connection;
  try {
    connection = await getDBConnection(dbUrl, dbUser, dbPassword);
    // Get all the queries
    const queries = await xmlService.parseQueryFromXml(xmlData);
    let rs = {};
    for (let i = 0; i < queries.length; i++) {
      const queryObj = await xmlService.parseQueryTag(queries[i], param);
      const queryResult = await getQueryResult(queryObj, param, connection);
      if (queryResult) {
        _.merge(rs, queryResult);
      }
    }
    return rs;
  } catch (err) {
    console.error(err);
    return {};
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
}

async function getDBConnection(dbUrl, dbUser, dbPassword) {
  const connection = await oracledb.getConnection({
    user: dbUser,
    password: dbPassword,
    connectString: dbUrl,
  });
  return connection;
}

/**
 * Get oAuth2 token from the endpoint.
 * @param {*} authConfig
 * @returns
 */
async function getToken(authConfig) {
  const authRequestUrl = `${authConfig.server}${authConfig.authUrl}`;
  const details = {
    username: authConfig.userName,
    password: authConfig.password,
    client_id: authConfig.clientId,
    client_secret: authConfig.clientSecret,
    grant_type: authConfig.grantType,
  };
  let formBody = [];
  for (let property in details) {
    const encodedKey = encodeURIComponent(property);
    const encodedValue = encodeURIComponent(details[property]);
    formBody.push(encodedKey + "=" + encodedValue);
  }
  formBody = formBody.join("&");
  const response = await axios.post(authRequestUrl, formBody, {
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
  });

  return response.data;
}

/**
 * Modify the endpoint url with the parameter and parameter defination.
 * Logic:
 *  1. Replace the tags in the url.
 *  2. Add the remain parameter as the query parameters.
 * @param {*} apiUrl
 * @param {*} param
 * @param {*} paramsMeta
 * @returns
 */
function replaceUrlPlaceHolder(apiUrl, param, paramsMeta) {
  let rs = apiUrl;
  const urlRegex = /{[^{}]+}/gi;
  const match = apiUrl.match(urlRegex);
  let clonedParam = _.clone(param);
  // Replace the placeholder
  if (match) {
    for (let i = 0; i < match.length; i++) {
      const element = match[i];
      const key = element.slice(1, -1);
      if (param[key]) {
        rs = rs.replace(element, param[key]);
        delete clonedParam[key];
      }
    }
  }
  // Add the remain parameters as the url parameter
  const remainKeys = Object.keys(clonedParam);
  if (remainKeys.length > 0) {
    if (apiUrl.indexOf("?") === -1) {
      rs = rs + "?";
    }
    for (let i = 0; i < remainKeys.length; i++) {
      const tmpKey = remainKeys[i];
      const paramDefine = paramsMeta.find((ele) => ele.name === tmpKey);
      // If current key is not part of the parameters in the current endpoint, ignore it.
      if (!paramDefine) {
        continue;
      }
      const tmpValue = encodeURIComponent(clonedParam[tmpKey]);
      if (rs.endsWith("?")) {
        rs = `${rs}${remainKeys[i]}=${tmpValue}`;
      } else {
        rs = `${rs}&${remainKeys[i]}=${tmpValue}`;
      }
    }
  }
  return rs;
}

/**
 * Get the respose of an endpoint. Add the token and x-request_id to the header.
 * @param {*} endpoint
 * @param {*} param
 * @param {*} dataSourceConfig
 * @returns
 */
async function getEndpointResponse(endpoint, param, dataSourceConfig, reqHeader) {
  const parameterDefines = xmlService.getTagParameterDefine(endpoint);
  const path = endpoint.$.path;
  const apiUrl = `${dataSourceConfig.server}${path}`;
  const replacedUrl = replaceUrlPlaceHolder(apiUrl, param, parameterDefines);
  // The token can be get from the reqHeader
  // If the dataSource has authUrl, it means we will get the token, otherwise, it will get the token from reqHeader.
  if (dataSourceConfig.authType === "oauth2" && dataSourceConfig.authUrl && !dataSourceConfig.authToken) {
    const tokenRes = await getToken(dataSourceConfig);
    if(tokenRes){
      dataSourceConfig.authToken = tokenRes.access_token;
    }
  }

  const headers = {};
  if (dataSourceConfig.authToken) {
    headers.Authorization = `Bearer ${dataSourceConfig.authToken}`;
  } else if (reqHeader.authToken) {
    headers.Authorization = `Bearer ${reqHeader.authToken}`;
  }
  headers["X-Request-Id"] = reqHeader.requestId || "FromReportTool";
  // Making a GET request with an authorization header
  try {
    const response = await axios.get(replacedUrl, {
      headers: headers,
    });
    const key = endpoint.$.key;
    const rs = {};
    rs[key] = response.data;
    return rs;
  } catch (error) {
    console.error(error);
    return rs;
  }
}

/**
 * Run the query and return the result as an object or an array of objects.
 * @param {*} rawQueryTag
 * @param {*} param
 * @param {*} connection
 * @returns
 */
async function getQueryResult(queryObj, param, connection) {
  // Get all the parameter definations
  const queryParam = createQueryParam(param, queryObj.parameterDefines);
  const result = await connection.execute(queryObj.sql, queryParam);
  const rowsAsObjects = result.rows.map((row) => {
    const obj = {};
    result.metaData.forEach((meta, index) => {
      obj[meta.name] = row[index];
    });
    return obj;
  });
  let rs = {};
  if (queryObj.resultType === "object") {
    rs[queryObj.key] = rowsAsObjects[0];
  } else {
    rs[queryObj.key] = rowsAsObjects;
  }
  return rs;
}

/**
 * Create the query parameter with the correct data type.
 * @param {*} param
 * @param {*} parameterDefines
 * @returns
 */
function createQueryParam(param, parameterDefines) {
  const result = {};
  Object.keys(param).forEach((propName) => {
    const paraDefine = parameterDefines.find((e) => e.name === propName);
    if (paraDefine) {
      if (paraDefine.type.toLowerCase() === "number") {
        let value = +param[propName];
        if (isNaN(value)) {
          if (param[propName] === "true") {
            value = 1;
          } else value = 0;
        }
        result[propName] = value;
      } else if (paraDefine.type.toLowerCase() === "date") {
        result[propName] = new Date(param[propName]);
      } else {
        result[propName] = param[propName];
      }
    }
  });
  return result;
}

/**
 * Use eval to run the postFunction and return the final data.
 * @param {} postFunction
 * @param {*} data
 * @returns
 */
function runPostFunction(postFunction, data) {
  if (!postFunction) {
    return data;
  }
  try {
    eval(postFunction);
    return main(data);
  } catch (error) {
    console.error(error);
    return data;
  }
}

async function loadFileFromUrl(url, webConfig) {
  let finalUrl = url;
  const headers = {};
  if (webConfig.server) {
    finalUrl = `${webConfig.server}${url}`;
  }
  if (webConfig.authToken) {
    headers.Authorization = `Bearer ${webConfig.authToken}`;
  }
  if (webConfig.requestId) {
    headers["X-Request-Id"] = webConfig.requestId || "FromReportTool";
  }
  const response = await axios.get(finalUrl, {
    responseType: 'arraybuffer',
    headers: headers,
  });
  let fileName = response.headers["content-disposition"] || "Unknown";
  if (fileName) {
    let match = fileName.match(/filename=(.*)/);
    if (match && match.length === 2) {
      fileName = match[1];
    }
  }
  return { fileName: fileName, data: response.data };
}

module.exports = { loadData, getDataFromDB, getDataFromUrl, runPostFunction, loadFileFromUrl };
