const ExcelJS = require("exceljs");
const fs = require("fs");
const path = require("path");
const _ = require("lodash");
const fileUtils = require("../utils/fileUtils");
const dataRetriveService = require('../services/dataRetriveService');
const xmlService = require("../services/xmlService");

/**
 * Generate a excel file based on an excel template.
 * For this POV, it only allow loop on one row.
 * Put the tag in the content not the note, because the note will be missing after insert new rows.
 * See a known bug: https://github.com/exceljs/exceljs/issues/2171
 * @param {*} data The data for generating the excel
 * @param {*} templatePath The path of the template. The path should under {projectDir}/templates.
 * @param {*} outputFileName The path of the output file. The path will under {projectDir}/output folder.
 * @returns
 */
async function generateExcelAsFile(data, templatePath, outputFileName) {
  const buf = await generateExcelAsBuffer(data, templatePath, outputFileName);
  // output the buffer as a file.
  // Add a timestamp into the filename for dev purpose.
  outputFileName = fileUtils.addTimestampToFileName(outputFileName);
  const outputFile = path.resolve(__dirname, "..", "output", outputFileName);
  fs.writeFileSync(outputFile, buf);
  return {
    success: true,
    filePath: outputFileName,
  };
}

/**
 * Generate a excel file based on an excel template.
 * For this POV, it only allow loop on one row.
 * @param {*} data The data for generating the excel
 * @param {*} templatePath The path of the template. The path should under {projectDir}/templates.
 * @returns
 */
async function generateExcelAsBuffer(data, templatePath, reportConfig) {
  let workbook;
  // If we have a temppate datasource defined, it means we need to get the template from URL.
  if(reportConfig && reportConfig.template.$.viewTemplateDatasource){
    const viewTemplateDs = getViewTemplateDs(reportConfig);
    let templateContent = await dataRetriveService.loadFileFromUrl(templatePath, viewTemplateDs);
    workbook = await loadExcelTemplateFromBuf(templateContent.data);
  } else {
    // Load the template from file
    workbook = await loadExcelTemplate(templatePath);
  }
  
  // Support multiple sheets in an excel template
  workbook.eachSheet(function (worksheet, sheetId) {
    // The total rows in the excel. It might be changed if the data has an array.
    let rowCount = worksheet.rowCount;
    // The total columns of the excel.
    let columnCount = worksheet.columnCount;
    // Loop the rows, the index starts from 1.
    for (let i = 1; i <= rowCount; i++) {
      const row = worksheet.getRow(i);
      // Handle one row. If this is a normal row, the return will be blank.
      // If the return is an available string, it means this is a loop row. The return is the path to the array. Ex: "items", "claims"
      const loopArrayPath = handleOneRow(row, columnCount, data);
      // The following is handleing a loop row with an array.
      if (loopArrayPath) {
        let loopArray = _.get(data, loopArrayPath);
        if (!loopArray || !Array.isArray(loopArray) || loopArray.length < 1) {
          // TDOD, clean this row

          // The data is not available, move to next row.
          continue;
        }
        for (let k = 0; k < loopArray.length; k++) {
          // insert a new row blow the i+k row.
          worksheet.duplicateRow(i + k, 1, true);
          // This is the created row, we will do some change on this row.
          const newRow = worksheet.getRow(i + k + 1);
          // The first parameter is the sample row. We add this row, because the duplicated row doesn't have notes on it.
          handleOneLoopRow(row, newRow, columnCount, loopArray[k]);
        }
        // Remove the sample line
        worksheet.spliceRows(i, 1);
        // Check all the formular with range function. Ex: sum, avg
        // Check all the formular after the added rows.
        modifyFormular(worksheet, i, loopArray.length);
        // Added rows: array.length, removed one sample row.
        const addedRows = loopArray.length - 1;
        // Go to the next line in the template.
        i += addedRows;
        // Add the newlines to total row number, otherwise the loop will fail.
        rowCount = rowCount + addedRows;
      }
    }
  });

  // buf is a nodejs Buffer, you can either write it to a
  // file or res.send it with express for example.
  const buf = await workbook.xlsx.writeBuffer();
  return buf;
}

// Load excel templaate from buffer
async function loadExcelTemplateFromBuf(fileContent) {
  // Load the existing workbook
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(fileContent);
  return workbook;
}

// Load excel template from local excel file
async function loadExcelTemplate(templatePath) {
  const templateFileName = path.resolve(__dirname, "..", "templates", templatePath);

  // Load the existing workbook
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile(templateFileName);

  return workbook;
}

/**
 * If the row is not a loop row, all the tag will be replaced with the data. The return will be blank.
 * If the row is a loop row, it will return the path of the loop data. Ex: "items", "data"
 * @param {*} row
 * @param {*} columnCount
 * @param {*} data
 * @returns
 */
function handleOneRow(row, columnCount, data) {
  // The regex for all the tags. Ex: {firstName}
  const tagRegex = /{.+?}/g;
  let loopArrayKey = "";
  for (let j = 1; j <= columnCount; j++) {
    const cell = row.getCell(j);
    const noteContent = getCellNote(cell);
    let cellValue = "";
    if (noteContent) {
      cellValue = noteContent;
      const tags = noteContent.match(tagRegex);
      if (tags && tags.length > 0) {
        // A tag startswith # means it is a loop
        if (tags[0].startsWith("{#")) {
          console.log("This is a loop row, loop object array: " + tags[0].substring(1));
          loopArrayKey = tags[0].substring(2, tags[0].length - 1);
          // If current row is a loop row, keep it and return;
          break;
        }
        // Support multiple tags in one cell.
        for (let t = 0; t < tags.length; t++) {
          const tag = tags[t];
          // Get the variable path. The tag looks like: {address.line1}.
          const varPath = tag.substring(1, tag.length - 1);
          // Get the value by path.
          let value = _.get(data, varPath);
          // If the tag is the only content of the cell, use the value directorly.
          // This will keep the type of the value.
          if(cellValue === tag){
            cellValue = value;
          }else{
            cellValue = cellValue.replace(tag, value);
          }
        }
        // Remove the note.
        delete cell.model.comment;
        delete cell._comment;
      }
    }
    if (cellValue) {
      cell.value = getValueByType(cellValue, cell.type);
    }
  }
  return loopArrayKey;
}

/**
 * Fill the data to a copied row.
 * @param {*} sampleRow The row with correct notes
 * @param {*} row The new row to be filled.
 * @param {*} columnCount The total column number.
 * @param {*} data The data to file the line. This is a object in an array.
 * @returns
 */
function handleOneLoopRow(sampleRow, row, columnCount, data) {
  // Regexp for all the tags
  const tagRegex = /{.+?}/g;
  // The formular look like this: 'D3*E3' or 'Sheet1!$D3*Sheet1!$E3'
  // This regex is for getting all the cell name that should be change to current row number.
  // "(?!\\d)" is for Negative lookahead assertion. If the sampleRow.number is 3, it will Match E3, not E33.
  const formulaRegex = new RegExp(`[A-Z]+${sampleRow.number}(?!\\d)`, "g");
  for (let j = 1; j <= columnCount; j++) {
    const cell = row.getCell(j);
    let cellValue = "";
    const sampleCell = sampleRow.getCell(j);
    const noteContent = getCellNote(sampleCell);
    let cellValueChanged = false;
    // If the sample cell has notes.
    if (noteContent) {
      cellValue = noteContent;
      let tags = noteContent.match(tagRegex);
      if (tags && tags.length > 0) {
        tags = tags.filter((tag => {
          // Remove all the loop tags
          if (tag.startsWith("{#") || tag === "{/}") {
            cellValue = cellValue.replace(tag, "");
          }
          return !tag.startsWith("{#") && tag !== "{/}";
        }));
        for (let t = 0; t < tags.length; t++) {
          const tag = tags[t];
          // Get the data path.
          const varPath = tag.substring(1, tag.length - 1);
          let value = data[varPath];
          if (cellValue === tag){
            cellValue = value;
          }else{
            if (!value) {
              value = "";
            }
            cellValue = cellValue.replace(tag, value);
          }
          cellValueChanged = true;
        }
      }
    }
    // If the value changed, use the new value.
    if (cellValueChanged) {
      cell.value = cellValue;//getValueByType(cellValue, sampleCell.type);
    }
    // If the sample cell has formula for the same line, modify it to fit the new line number.
    if (sampleCell.formula) {
      // Find if the sample line has formula on this line
      const cellNumbers = sampleCell.formula.match(formulaRegex);
      if (cellNumbers && cellNumbers.length > 0) {
        let formula = sampleCell.formula;
        for (let j = 0; j < cellNumbers.length; j++) {
          const tmpNumber = cellNumbers[j];
          // row.number-1, because we will remove the sample line.
          const newNumber = tmpNumber.replace(/\d+/g, "") + (row.number - 1);
          // Only replace the exactly match. Ex: If the formular is E3*E33, the new value is E10, The replace result will be E10*E33.
          const replaceExp = new RegExp(`${tmpNumber}(?!\\d)`, "g");
          // change to the current row number.
          formula = formula.replace(replaceExp, newNumber);
        }
        // Set the formula of the cell.
        cell.value = {
          formula: formula,
        };
      }
    }
  }
}

/**
 * Modify all the related formular after adding some new rows.
 * @param {*} worksheet The worksheet need to check.
 * @param {*} startLine The start number of the added rows.
 * @param {*} addedRows The total amount of the added rows.
 */
function modifyFormular(worksheet, startLine, addedRows) {
  // To match the formula like "SUM(F3:F5)*AVG(G3:G5)"
  const rangeFormulaRegex = /\([A-Z]+\d+:[A-Z]+\d+\)/g;
  // To match the formula like "A4, A5, G5"
  const cellFormulaRegex = /[A-Z]+\d+/g;

  let rowCount = worksheet.rowCount;
  // Loop the rows, the index starts from all the added lines.
  for (let i = startLine + addedRows; i <= rowCount; i++) {
    let row = worksheet.getRow(i);
    // Iterate through each cell in the row
    row.eachCell((cell, colNumber) => {
      // Check if the cell has a formula
      if (cell.formula) {
        let formula = cell.formula;
        const ranges = formula.match(rangeFormulaRegex);
        // If this is a range foumular, like: A10:A20
        if (ranges && ranges.length > 0) {
          for (let i = 0; i < ranges.length; i++) {
            const rangeArray = ranges[i].match(/\d+/g);
            const endLine = add(rangeArray[1], addedRows) - 1;
            // If the range include the new rows, modify the range. For the formula like: A3:A5
            if (startLine >= rangeArray[0] && startLine <= rangeArray[1]) {
              let newRange = ranges[i].replace("" + rangeArray[1], endLine + "");
              formula = formula.replace(ranges[i], newRange);
            } else if (rangeArray[0] === rangeArray[1] && endLine >= rangeArray[0]) {
              // For the formula like: I5:M5
              let newRange = ranges[i].replaceAll("" + rangeArray[1], endLine + "");
              formula = formula.replace(ranges[i], newRange);
            }
          }
        } else if (row.number > startLine + addedRows) {
          // only handle the line after the added lines.
          const cellNames = formula.match(cellFormulaRegex);
          if (row.number && cellNames.length > 0) {
            for (let i = 0; i < cellNames.length; i++) {
              const cellNumbers = cellNames[i].match(/\d+/g);
              // If the cell numbers is greater or equal to startLine, modify its number.
              if (cellNumbers && cellNumbers[0] && parseInt(cellNumbers[0]) >= startLine) {
                let newCellNumber = cellNames[i].replace(cellNumbers[0], add(cellNumbers[0], addedRows) - 1 + "");
                formula = formula.replace(cellNames[i], newCellNumber);
              }
            }
          }
        }
        if (formula !== cell.formula) {
          cell.value = {
            formula: formula,
          };
        }
      }
    });
  }
}

/**
 * Get the cell notes.
 * Design change: Put the tag in the content not the note, because the note will be missing after insert new rows. 
 * See the known bug: https://github.com/exceljs/exceljs/issues/2171
 * @param {*} cell
 * @returns
 */
function getCellNote(cell) {
  const note = cell.note;
  let noteContent = "";
  if (note && note.texts && note.texts[0]){
    noteContent = note.texts[0].text;
  } else {
    let value = cell.value;
    if((typeof value === 'string' || value instanceof String) 
      && value.indexOf("{") > -1){
      noteContent = value;
    }
  }
  return noteContent;
}

/**
 * Get the correct value with correct type
 * @param {} cellValue
 * @param {*} type
 * @returns
 */
function getValueByType(cellValue, type) {
  let rsValue = "";
  // We can add more cases if needed. See: ExcelJS.ValueType
  if (cellValue) {
    switch (type) {
      case ExcelJS.ValueType.Number:
        rsValue = +cellValue;
        break;
      case ExcelJS.ValueType.Date:
        rsValue = new Date(cellValue);
        break;
      default:
        rsValue = cellValue;
    }
  } else if (type === ExcelJS.ValueType.Number) {
    rsValue = 0;
  }
  return rsValue;
}

// Add two string numbers.
function add(s1, s2) {
  return parseInt(s1, 10) + parseInt(s2, 10);
}

function getViewTemplateDs(reportConfig){
  const datasources = xmlService.getDatasourceConfigs(reportConfig);
  const ds = xmlService.findDatasource(datasources, 'url', reportConfig.template.$.viewTemplateDatasource);
  return ds;
}

module.exports = { generateExcelAsFile, generateExcelAsBuffer };
