const fs = require("fs");
const path = require("path");
const xml2js = require("xml2js");
const htmlParser = require("html-parse-stringify");

/**
 * Read xml file as string
 * @param {*} xmlPath
 * @returns
 */
async function readXmlFile(xmlPath) {
  try {
    console.log("Parsed XML:", xmlPath);
    // Load the template file as utf8 txt
    const content = fs.readFileSync(path.resolve(__dirname, "..", "templates", xmlPath), { encoding: "UTF-8" });
    return content;
  } catch (error) {
    console.error("Error reading XML:" + xmlPath, error);
    return {};
  }
}

/**
 * Parse xml file by file path.
 * @param {*} xmlPath
 * @returns
 */
async function parseXmlFile(xmlPath) {
  try {
    console.log("Parsed XML:", xmlPath);
    // Load the template file as utf8 txt
    const content = fs.readFileSync(path.resolve(__dirname, "..", "templates", xmlPath), { encoding: "UTF-8" });
    return await parseXml(content);
  } catch (error) {
    console.error("Error parsing XML:" + xmlPath, error);
    return {};
  }
}

/**
 * Parse xml string.
 * @param {*} xmlData
 * @returns
 */
async function parseXml(xmlData) {
  try {
    console.log("Parsing XML ...");
    // With parser
    const parser = new xml2js.Parser({ explicitArray: false });
    const rs = await parser.parseStringPromise(xmlData);
    return rs;
  } catch (error) {
    console.error("Error parsing XML.", error);
    return {};
  }
}

/**
 * Parse select tag to get the sql.
 * @param {*} rawXml The query tag as a string.
 * @param {*} param The parameter that user sent.
 * @returns
 */
function parseSqlFromXml(rawXml, param) {
  const selectRegex = /<select[\s\S]*?\/select>/i;
  const match = rawXml.match(selectRegex);
  let statement = "";
  if (match) {
    let ast = htmlParser.parse(match[0]);
    statement = convertChildren(ast[0].children, param);
    console.log(statement);
  } else {
    console.log("can't find <select> tag in the html");
  }
  return statement;
}

/**
 * Find all the query tags in the xml file.
 * @param {*} rawXml The original xml as a string.
 * @returns
 */
function parseQueryFromXml(rawXml) {
  const queryRegex = /<query[\s\S]*?\/query>/gi;
  const match = rawXml.match(queryRegex);
  let queries = [];
  if (match) {
    return match;
  } else {
    console.log("can't find <query> tag in the html");
  }
  return queries;
}

/**
 * For parse select tag. It will join the sql statements within the children of select tag.
 * @param {*} children
 * @param {*} parameter
 * @returns
 */
function convertChildren(children, parameter) {
  let statement = "";
  for (let i = 0; i < children.length; i++) {
    const child = children[i];
    statement += convertChild(child, parameter);
  }
  return statement;
}

/**
 * Get sql statement within the current tag.
 * @param {*} child
 * @param {*} parameter
 * @returns
 */
function convertChild(child, parameter) {
  if (child.type == "text") {
    return child.content;
  } else if (child.type == "tag") {
    // Add more tags here to supperted new features.
    switch (child.name.toLowerCase()) {
      case "if":
        return convertIf(child, parameter);
      default:
        throw new Error("Unsupport tag.");
    }
  } else {
    return "";
  }
}

function convertIf(child, parameter) {
  try {
    let evalString = child.attrs.test;
    evalString = evalString.replace(/ and /gi, " && ");
    evalString = evalString.replace(/ or /gi, " || ");
    // Just in case, user use "&amp;"" as "&"
    evalString = evalString.replace(/(\&amp\;)/gi, "&");

    // replace == to === for strict evaluate
    evalString = evalString.replace(/==/g, "===");
    evalString = evalString.replace(/!=/g, "!==");
    if (eval(evalString)) {
      return convertChildren(child.children, parameter);
    } else {
      return "";
    }
  } catch (e) {
    throw new Error("Error occurred during convert <if> element.");
  }
}

/**
 * Get the configuration of the query tag.
 * @param {*} rawQueryTag
 * @param {*} parameter
 * @returns
 */
async function parseQueryTag(rawQueryTag, parameter) {
  const ast = await parseXml(rawQueryTag);
  const parameterDefines = getTagParameterDefine(ast.query);
  const sql = parseSqlFromXml(rawQueryTag, parameter);
  const rs = {
    sql: sql,
    parameterDefines: parameterDefines,
    key: ast.query.$.key,
    resultType: ast.query.$.resultType,
    dataSource: ast.query.$.dataSource,
  };
  return rs;
}

/**
 * Get all the parameter tags under the parent tag.
 * @param {*} tag
 * @returns
 */
function getTagParameterDefine(tag) {
  const parameters = tag.parameter;
  let rs = [];
  if (Array.isArray(parameters)) {
    parameters.forEach((ele) => {
      rs.push({
        name: ele.$.name,
        type: ele.$.type,
        optional: ele.$.optional,
      });
    });
  } else {
    rs.push({
      name: parameters.$.name,
      type: parameters.$.type,
      optional: parameters.$.optional,
    });
  }
  return rs;
}

/**
 * Get the post function defined in the template.
 * @param {*} rawXml
 * @returns
 */
function getPostFunctionStr(rawXml) {
  const queryRegex = /<postFunction[\s\S]*?\/postFunction>/gi;
  const match = rawXml.match(queryRegex);
  let functionStr = "";
  if (match) {
    let ast = htmlParser.parse(match[0]);
    if (ast[0] && ast[0].children && ast[0].children[0]) {
      functionStr = ast[0].children[0].content;
    } else {
      console.log("Can not find correct function");
    }
  } else {
    console.log("No <postFunction> tag in the html");
  }
  if (functionStr) {
    functionStr = functionStr.trim();
    functionStr = replaceSpecalCharFromXmlFormat(functionStr);
  }
  return functionStr;
}

/**
 * Xml helpers to convert "&" to "&amp;"
 * @param {*} str
 * @returns
 */
function replaceSpecalCharToXmlFormat(str) {
  str = str.replace(/\&/g, "&amp;");
  str = str.replace(/\</g, "&lt;");
  str = str.replace(/\>/g, "&gt;");
  str = str.replace(/\"/g, "&quot;");
  return str;
}

/**
 * Xml helpers to convert "&amp;" to "&"
 * @param {*} str
 * @returns
 */
function replaceSpecalCharFromXmlFormat(str) {
  str = str.replace(/(\&amp\;)/g, "&");
  str = str.replace(/(\&lt\;)/g, "<");
  str = str.replace(/(\&gt\;)/g, ">");
  str = str.replace(/(\&quot\;)/g, '"');
  return str;
}

function getDatasourceConfigs(reportConfig) {
  const ret = [];
  const dataSources = reportConfig.template.dataSource;
  if (Array.isArray(dataSources)) {
    for (let i = 0; i < dataSources.length; i++) {
      const ds = getDataSourceConfig(dataSources[i]);
      if (ds) {
        ret.push(ds);
      }
    }
  } else {
    ret.push(getDataSourceConfig(dataSources));
  }
  return ret;
}

function getDataSourceConfig(dataSourceTag) {
  let rs = {
    type: dataSourceTag.$.type,
    id: dataSourceTag.$.id,
  };
  let propTags = dataSourceTag.property;
  if (rs.type === "sql") {
    rs.dbUrl = getProperyValueByName(propTags, "url");
    rs.dbUser = getProperyValueByName(propTags, "username");
    rs.dbPassword = getProperyValueByName(propTags, "password");
  } else if (rs.type === "url") {
    rs.server = getProperyValueByName(propTags, "server");
    rs.path = getProperyValueByName(propTags, "path");
    if (rs.server.endsWith("/")) {
      rs.server = server.substring(0, server.length - 1);
    }
    const authType = getProperyValueByName(propTags, "authType");
    rs.authType = authType;
    if (authType.toLocaleLowerCase() === "oauth2") {
      rs.authUrl = getProperyValueByName(propTags, "authUrl");
      rs.userName = getProperyValueByName(propTags, "userName");
      rs.password = getProperyValueByName(propTags, "password");
      rs.clientId = getProperyValueByName(propTags, "clientId");
      rs.clientSecret = getProperyValueByName(propTags, "clientSecret");
      rs.grantType = getProperyValueByName(propTags, "grantType");
    }
  }
  return rs;
}

function findDatasource(dsConfigs, type, id) {
  let ret;
  if (id) {
    ret = dsConfigs.find((ele) => ele.id === id);
  }
  if (!ret) {
    ret = dsConfigs.find((ele) => ele.type === type);
  }
  return ret;
}

function getProperyValueByName(properties, name) {
  let rs = "";
  // If the tag only has one property, the properties is an object.
  if (Array.isArray(properties)) {
    for (let i = 0; i < properties.length; i++) {
      const prop = properties[i];
      if (prop.$.name === name) {
        rs = prop.$.value;
        break;
      }
    }
  } else if (properties.$.name === name) {
    rs = properties.$.value;
  }
  return rs;
}


/**
 * Read the connection info defined in the xml.
 * @param {} reportConfig
 * @returns
 */
async function getDbConnectionInfo(reportConfig) {
  const webConnectionInfo = reportConfig.template.dataSource.property;
  const urlConfig = {
    server: xmlService.getProperyValueByName(webConnectionInfo, "server"),
    path: xmlService.getProperyValueByName(webConnectionInfo, "path"),
  };
  if (urlConfig.server.endsWith("/")) {
    urlConfig.server = server.substring(0, server.length - 1);
  }
  const authType = xmlService.getProperyValueByName(webConnectionInfo, "authType");
  if (authType.toLocaleLowerCase() === "oauth2") {
    urlConfig.authUrl = xmlService.getProperyValueByName(webConnectionInfo, "authUrl");
    urlConfig.userName = getProperyValueByName(webConnectionInfo, "userName");
    urlConfig.password = getProperyValueByName(webConnectionInfo, "password");
    urlConfig.clientId = getProperyValueByName(webConnectionInfo, "clientId");
    urlConfig.clientSecret = getProperyValueByName(webConnectionInfo, "clientSecret");
    urlConfig.grantType = getProperyValueByName(webConnectionInfo, "grantType");
  }
  return urlConfig;
}

module.exports = {
  parseXmlFile,
  parseXml,
  readXmlFile,
  parseSqlFromXml,
  parseQueryFromXml,
  parseQueryTag,
  getTagParameterDefine,
  getPostFunctionStr,
  getDatasourceConfigs,
  findDatasource,
  getProperyValueByName,
  getDbConnectionInfo,
};
