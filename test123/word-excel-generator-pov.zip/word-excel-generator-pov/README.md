# word-excel-generator-pov

This is a prove of concept of the replate and word(or excel) generation.

## How to run it

Pleae follow the steps to run it.

- Pull this project
- Run "npm install" in the root of project folder
- Run "node ./bin/www" or "npm run start" to start the service, the default port is 3000.
- The templates is in "./templates" folder.
- Use postman to send the data to the server. The post body can be found in the "./test_data" folder. Only two endpoints are available:
    - POST http://localhost:3000/generate/excel
    - POST http://localhost:3000/generate/excelAsStream       // Return a stream instead of generate a file on the server
    - POST http://localhost:3000/generate/word
    - POST http://localhost:3000/generate/wordAsStream        // Return a stream instead of generate a file on the server
    - GET  http://localhost:3000/report?template=beneficiary_paid_records.xml&phn=18092700&claimStatusType=61
    - GET  http://localhost:3000/report?template=code_types_word_url.xml&codeType=RESIDENT_STATUS
    - GET  http://localhost:3000/report?template=code_types_word_db.xml&codeType=RESIDENT_STATUS
- If the generation success, you will see the generated file name in the returned message.
- Check the generatate file in "output" folder.

All the GET request will return the generated file as a stream. You will need to save it and then open it.

## Introduction

The word generation is based on docxtemplater, we use the free features. See all [the supported tags](https://docxtemplater.com/docs/tag-types/)

The excel generation is based on excelJs, because that feature is not free in docxtemplater and we only use very basic feature in our system. We write some simple logical to surrore the same tags as docxtemplater. Currently, we only support loop in excel.

## Report Template

A report template will define the datasource of the temlate and the view template of the report.

We support the following types of datasource:

- url. It supports Http(s) call
- sql. It supports DB query

Each datasource will need to define the connection info.
The <query> tag and <url> tag will define how to get the dataset.
A template could have multiple query or multiple url to get multiple datasets. Each dataset has a key property, which will be the name of the dataset in the final data.

The template also support a post function, the function must be named as "main", the input is the dataset from the datasource, the output must be the final data.

The following is an example:

### url example, generate a word document

```xml
<!-- The file could be a relative path in local or a url.-->
<template viewTemplate="code_types.docx">
    <!-- The type could be sql or url. If the type is url, the return must be a JSON. -->
    <dataSource type="url">
        <property name="server" value="https://dev.deltaware.ca"/>
        <!-- Only support oauth2 or none in the POC project. -->
        <property name="authType" value="oauth2"/>
        <property name="authUrl" value="/auth/realms/medigent/protocol/openid-connect/token"/>
        <property name="userName" value="hello2"/>
        <property name="password" value="Password1"/>
        <property name="clientId" value="myapp"/>
        <property name="clientSecret" value=""/>
        <property name="grantType" value="password"/>
    </dataSource>
    <endpoint key="codeTypes" path="/api/v3/codetype/{codeType}/code/?enabled={enabled}">
        <!-- The code of the type. EX: CONTROL_PARAMS-->
        <parameter name="codeType" type="string" optional="false" />
        <parameter name="enabled" type="string" optional="true" />
        <parameter name="suppressed" type="string" optional="true" />
    </endpoint>
    <endpoint key="beneficiary" path="/api/v3/beneficiary/{beneficiaryId}">
        <parameter name="beneficiaryId" type="string" optional="false" />
    </endpoint>
</template>
```

### DB example, generate a excel file

```xml
<template viewTemplate="beneficiary_paid_records_no_formular.xlsx">
    <!-- The type could be sql or url. If the type is url, the return must be a JSON. -->
    <dataSource type="sql">
        <!-- Optional, use the default one if not set.-->
        <property name="url" value="vndev127210pe-db.dsidev.com:1521/cps"/>
        <property name="username" value="medcrtr"/>
        <property name="password" value="delenn"/>
    </dataSource>
    <query key="data" resultType="array">
        <parameter name="phn" type="number" optional="false" />
        <parameter name="claimStatusType" type="number" optional="true" />
        <parameter name="startDate" type="date" optional="true" />
        <parameter name="endDate" type="date" optional="true" />
        <select>
            SELECT
                cp.id as "id",
                cp.client_first_name as "firstName",
                cp.client_last_name as "surname",
                cp.phn as "beneficiaryPHN",
                TO_CHAR(ck.clm_stts) as "claimStatusType",
                (select cs.txt from medcrtr.claim_status cs where cs.id = ck.clm_stts) as "claimStatusDescription",
                ck.dte_of_srvce as "dateOfService",
                TO_CHAR(cp.last_refill_date, 'YYYY-MM-DD') as "lastFillDate",
                ck.prvdr_id as "serviceProviderId",
                TO_CHAR(ck.clm_type) as "claimType",
                ck.fee_cde as "productId",
                (select dm.label_name from  medcrtr.din_master dm where ck.fee_cde = dm.din) as "productName",
                cp.dspnsd_strength as "productStrength",
                cp.dspnsd_dosage as "productDosage",
                ck.fclty_id as "pharmacyId",
                (select sp.compressed_name from medcrtr.service_provider sp where sp.id = ck.fclty_id ) as "pharmacyName",
                cp.paid_subprogram_code as "programCode",
                cp.paid_subprogram_code_id as "programId",
                cp.special_authorization_number as "priorAuthId",
                ck.clnt_id as "beneficiaryId",
                ck.cmnt as "comment",
                ck.clmd_amnt as "claimedAmount",
                ck.aprvd_amnt as "approvedAmount",
                cp.paid_drug_cost AS "paidDrugCost",
                cp.paid_cost_upcharge AS "paidUpcharge",
                cp.paid_professional_fee AS "paidProfFee",
                cp.paid_compound_fee AS "paidCompoundFee", 
                cp.paid_special_services_fee AS "paidSpecServFee",
                cp.dspnsd_previously_paid AS "previouslyPaid"
            FROM medcrtr.claim_pharmacy cp
            inner join medcrtr.claim_key ck on ck.id=cp.id
            inner join medcrtr.service_provider sp on sp.id=ck.prvdr_id
            where (cp.phn=:phn or 1=1)
            <if test="parameter.claimStatusType">
                AND ck.clm_stts = :claimStatusType
            </if>
            <if test="parameter.startDate and parameter.endDate">
                AND cp.date_processed between :startDate and :endDate
            </if>
            order by "id"
        </select>
    </query>
    <!-- The input is the query result, the output is the data for the report-->
    <postFunction>
        function main(queryRs){
            if(queryRs.data &amp;&amp; Array.isArray(queryRs.data)){
                let subTotal = {
                    paidDrugCost: 0,
                    paidUpcharge: 0,
                    paidProfFee: 0,
                    paidCompoundFee: 0,
                    paidSpecServFee: 0,
                    previouslyPaid: 0,
                }
                for (let i = 0; i &lt; queryRs.data.length; i++) {
                    const claim = queryRs.data[i];
                    if(claim.paidDrugCost){
                        subTotal.paidDrugCost += claim.paidDrugCost
                    }
                    if(claim.paidUpcharge){
                        subTotal.paidUpcharge += claim.paidUpcharge
                    }
                    if(claim.paidProfFee){
                        subTotal.paidProfFee += claim.paidProfFee
                    }
                    if(claim.paidCompoundFee){
                        subTotal.paidCompoundFee += claim.paidCompoundFee
                    }
                    if(claim.paidSpecServFee){
                        subTotal.paidSpecServFee += claim.paidSpecServFee
                    }
                    if(claim.previouslyPaid){
                        subTotal.previouslyPaid += claim.previouslyPaid
                    }
                }
                queryRs.subTotal = subTotal;
                queryRs.total = subTotal.paidDrugCost + subTotal.paidUpcharge + subTotal.paidProfFee + subTotal.paidCompoundFee + subTotal.paidSpecServFee + subTotal.previouslyPaid;
            }
            return queryRs;
        }
    </postFunction>
</template>

The structure of the query tag is inspired by MyBatis, a very popular persistence framework in Java. See: [Mybatis Dynamic SQL](https://mybatis.org/mybatis-3/dynamic-sql.html). We use the similiar select tag for our report tool. We write the parser ourself. Currently, we only support <query> and <if> tags. If there are more tag support needs to be supported, pleae modify xmlService.js.

## View Template

A view template is for define how the report looks like. It suppport the format of word(.docx) and excel(.xlsx) document.

The main idea of this template is inspired by docxtemplater, its tag is enough to use and well defined.

In the word template, all the tags are available, because docxtemplater is one of our dependency. However, for excel file, there is no similar library, we implement it ourself with exceljs library. Currently, we only support variable tag and loop tag.

All those tags are part of the main content of the template. We plan to use note on a cell to store the tag, but the exceljs has a unsolved bug, when we add new rows, the tags after that row will be gone. See [[BUG] Row outline & cell note not working after worksheet.insertRow](https://github.com/exceljs/exceljs/issues/2171)

Note: Since we have the tag in the cell, the cell value type is always "string". We will use the type of the final data to reset the cell value type. Please make sure the type is correct, otherwise the formular might not working.

The formular could work in the excel template. When we insert new rows, the formular will be modified after the row changes. Currently, we only support to modify the range in the formular like the following: D2:D4 or E6:J6. If there are any new format needs to be supported, please look into the "modifyFormular" function in the generateExcelService.js.

