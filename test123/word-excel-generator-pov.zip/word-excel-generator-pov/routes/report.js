const express = require("express");
const router = express.Router();
const generateDocService = require('../services/generateDocxService');
const generateExcelService = require('../services/generateExcelService');
const xmlService = require('../services/xmlService');
const dataRetriveService = require('../services/dataRetriveService');
const fileUtils = require("../utils/fileUtils");

const _ = require("lodash");

/* This is just a demo for getting data from a url. */
router.get("/", async function (req, res, next) {
  let fileName = req.query.template;
  let xmlData = '';
  let loadedTemplate = '';
  // We we make a call inside the template, the headed is needed.
  const headers =  {
    requestId: req.headers["X-Request-Id"],
    authToken: req.headers["Authorization"],
  };
  if(fileName.trim().startsWith("http")){
    // Add the incoming token and request to the header.
    loadedTemplate = await dataRetriveService.loadFileFromUrl(fileName, headers);
    xmlData = loadedTemplate.data;
    xmlData = xmlData.toString("UTF-8");
  } else {
    xmlData = await xmlService.readXmlFile(fileName);
  }
  // Read xml file as a string
  // Parse xml as an java object.
  let reportConfig = await xmlService.parseXml(xmlData);
  if(reportConfig){
    const viewTemplate = reportConfig.template.$.viewTemplate;
    let parameters = _.clone(req.query);
    // Remove this parameter, we will use the other parameters as the query parameters.
    delete parameters.template;

    let loadedData = await dataRetriveService.loadData(reportConfig, parameters, xmlData, headers);
    // If the template defines the post function, execute it to get the new data
    const postFunction = xmlService.getPostFunctionStr(xmlData);
    if(postFunction){
      loadedData = dataRetriveService.runPostFunction(postFunction, loadedData);
    }
    // Add query parameters to the data for generating the document.
    loadedData.parameters = parameters;

    let generateResult, mimetype;
    if(viewTemplate.endsWith('.xlsx')){
      generateResult = await generateExcelService.generateExcelAsBuffer(loadedData, viewTemplate, reportConfig);
      mimetype = "application/vnd.ms-excel";
    }else if(viewTemplate.endsWith('.docx')){
      generateResult = await generateDocService.generateDocxAsBuffer(loadedData, viewTemplate, reportConfig);
      mimetype = "application/msword";
    }
    if(generateResult){
      const downloadFileName = fileUtils.addTimestampToFileName(viewTemplate);;
      res.setHeader('Content-disposition', 'attachment; filename=' + downloadFileName);
      res.setHeader('Content-type', mimetype);
      res.send(generateResult);
    } else {
      res.setHeader('Content-type', 'application/json');
      res.send(JSON.stringify({Message:"Fail to generate the report"}, null, 4));
    }
  }else{
    console.log("Can't parse template:"+fileName);
    res.setHeader('Content-type', 'application/json');
    res.send(JSON.stringify({Message:"Fail to generate the report"}, null, 4));
  }
});

module.exports = router;
