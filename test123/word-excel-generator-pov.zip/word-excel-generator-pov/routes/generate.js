const path = require("path");
const express = require('express');
const router = express.Router();
const generateDocService = require('../services/generateDocxService');
const generateExcelService = require('../services/generateExcelService');
const fileUtils = require("../utils/fileUtils");

/* GET users listing. */
router.post('/word', async function(req, res, next) {
  const data = req.body.data;
  const destination = req.body.destination;
  const templatePath = req.body.templatePath;
  const generateResult = await generateDocService.generateDocxAsFile(data, templatePath, destination);
  res.json(generateResult);
});

/* GET users listing. */
router.post('/excel', async function(req, res, next) {
  const data = req.body.data;
  const destination = req.body.destination;
  const templatePath = req.body.templatePath;
  const generateResult = await generateExcelService.generateExcelAsFile(data, templatePath, destination);
  res.json(generateResult);
});

/* Return the word file content as a stream. Like a download. */
router.post('/wordAsStream', async function(req, res, next) {
  const data = req.body.data;
  const destination = req.body.destination;
  const templatePath = req.body.templatePath;
  const generateResult = await generateDocService.generateDocxAsBuffer(data, templatePath);
  const filename = fileUtils.addTimestampToFileName(path.basename(destination));
  const mimetype = "application/msword";
  res.setHeader('Content-disposition', 'attachment; filename=' + filename);
  res.setHeader('Content-type', mimetype);
  res.send(generateResult);
});

/* Return the excel file content as a stream. Like a download. */
router.post('/excelAsStream', async function(req, res, next) {
  const data = req.body.data;
  const destination = req.body.destination;
  const templatePath = req.body.templatePath;
  const generateResult = await generateExcelService.generateExcelAsBuffer(data, templatePath);
  const filename = fileUtils.addTimestampToFileName(path.basename(destination));
  const mimetype = "application/vnd.ms-excel";
  res.setHeader('Content-disposition', 'attachment; filename=' + filename);
  res.setHeader('Content-type', mimetype);
  res.send(generateResult);
});

module.exports = router;
