const express = require("express");
const router = express.Router();
const path = require("path");
const fs = require('fs');
const fileUtils = require("../utils/fileUtils");

const _ = require("lodash");

/* This is just a demo for getting data from a url. */
router.get("/*", async function (req, res, next) {
  const filePath = req.path;
  const realPath =  path.join(__dirname, '..', 'templates', filePath);
  const fileName = path.basename(realPath);
  console.log(`looking for the file: ${realPath}`);
  if (fs.existsSync(realPath)){
    // return the json file as the response
    console.log(`File found. ${realPath}`);
    let fileContent = await fs.readFileSync(realPath);
    res.setHeader("Content-Disposition", `attachment;filename=${fileName}`);
    res.setHeader('Content-Type', 'application/octet-stream');
    res.send(fileContent);
  } else {
    console.log("Can't find the template");
    res.send("Can't find the template");
  }
});

module.exports = router;
