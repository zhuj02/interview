
function addTimestampToFileName(fileName){
    const lastSlashIndex = fileName.lastIndexOf("/");
    if(lastSlashIndex){
      fileName = fileName.substring(lastSlashIndex+1);
    }
    const lastIndex = fileName.lastIndexOf(".");
    const timeStamp = new Date()
      .toISOString()
      .replace(/[^0-9]/g, "")
      .substring(0, 14);
    fileName = `${fileName.substring(0, lastIndex)}_${timeStamp}${fileName.substring(lastIndex)}`;
    return fileName;
}

module.exports = {addTimestampToFileName};
